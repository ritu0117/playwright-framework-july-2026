import {page} from '@playwright/test';

export class DashboardPage{

    
    constructor(page)
    {

      
      this.page= page;

      this.menuIcon=page.getByAltText("menu")

     this.signOutButton=page.getByText("Sign out",{exact:true})

    
    }

   
   async clickonmenuIcon()  
   {
     await this.menuIcon.click()
   }


    async signoutToApplication()  
   {
     await this.signOutButton.click()
   }

  
}