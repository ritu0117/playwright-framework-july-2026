import {page} from '@playwright/test';

export class Loginpage{

    //all the locatore will define into constractor/its called automaticly when we create the object of the class
    
    constructor(page)
    {

      //will use 'this' keyword so we can start using this page in this class as well
      this.page= page;

      this.usernameField=page.getByPlaceholder("Enter Email")
      this.passwordField=page.getByPlaceholder("Enter Password")
      this.loginButton=page.getByText("Sign in",{exact:true})

      this.newUrlSignUpLink=page.getByText("New user? Signup",{exact:true})//new user sign in also belongs to login page
      
      this.errorMessage=page.locator(".errorMessage") // capturting error messge with diff user
    }

  //Now creating methods which performs action on above locators- one method for each elements
   
   async loginToApplication(username,password)  // one method one action
   {
      await this.usernameField.fill(username)
      await this.passwordField.fill(password)
      await this.loginButton.click()


   }

   async clickonNewuserSignuplink() // creating another method for new Urlsignin
   {
     await this.newUrlSignUpLink.click()

   }

   async getErrorMessage() // this method to captuting error message
   {
     return await this.errorMessage.textContent();

   }


}