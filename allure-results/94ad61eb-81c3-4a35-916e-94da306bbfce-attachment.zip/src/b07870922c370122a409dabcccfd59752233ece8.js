import {test,expect} from '@playwright/test';
import { Loginpage} from '../../pages/Loginpage.js'; //../.. its two level up , .js
import { DashboardPage } from '../../pages/Dashboardpage.js';
import userO from '../../testdata/user.json' //user0 object

test('login to application',async({page})=>

    {
      await page.goto('/login');

      //creating object of Loginpage class
      const loginpage =new Loginpage(page); //() in constractor pass page // later on will keep this code inside the fixture


      console.log(`test data used in this test ${userO.username} and ${userO.password}`);
      await loginpage.loginToApplication(userO.username,userO.password) // abstraction use essisial feature hiding the backround details // also  use data from json testdata folder user file
      
     const dashboardPage=new DashboardPage(page);

     await dashboardPage.clickonmenuIcon();
     await dashboardPage.signoutToApplication();


    });
