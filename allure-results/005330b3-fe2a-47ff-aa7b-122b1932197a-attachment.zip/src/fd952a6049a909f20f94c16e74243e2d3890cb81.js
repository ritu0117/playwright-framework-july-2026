import {test} from '@playwright/test'

//base page class to be extended by all page objects
export class BasePage
{
   constructor(page)
   {
    this.page=page;

   }
   
   //waits,alter,fill,type,dropdown,handle multiple tabs, capture text and more method can be added here

   async type(selector,text)
   {
    await selector.fill(text)
   }


   async click(selector)
   {
    await selector.click()
   }

   async navigateToapplication(url)
   {
    await this.page.goto(url);
   }

    async uploadFile(selector,filepaths)
   {
    await selector.setInputFiles(filepaths);
   }


   async getText(selector)
   {
    return await selector.textContent()
   }
}